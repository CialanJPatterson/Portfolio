import{a0 as a}from"./ChcujYhf.js";a();
