import{l as o,a as r}from"../chunks/CminKL6y.js";export{o as load_css,r as start};
